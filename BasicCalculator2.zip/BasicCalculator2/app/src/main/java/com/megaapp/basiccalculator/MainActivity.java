package com.megaapp.basiccalculator;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    Button btn0, btn1, btn2, btn3, btn4, btn5, btn6,  btn7, btn8, btn9,btnAdd, btnSub, btnMulti, btnDiv, btnDot, btnEqual, btnClear;
    private boolean isOpPressed = false;
    private  double firstNumber = 0;
    private int secondNumberIndex = 0;
    private char currentOp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.textView);

        btn0 = (Button) findViewById(R.id.btn0);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);
        btn4 = (Button) findViewById(R.id.btn4);
        btn5 = (Button) findViewById(R.id.btn5);
        btn6 = (Button) findViewById(R.id.btn6);
        btn7 = (Button) findViewById(R.id.btn7);
        btn8 = (Button) findViewById(R.id.btn8);
        btn9 = (Button) findViewById(R.id.btn9);
        btnAdd = (Button) findViewById(R.id.btnAdd);
        btnSub = (Button) findViewById(R.id.btnSub);
        btnMulti = (Button) findViewById(R.id.btnMulti);
        btnDiv = (Button) findViewById(R.id.btndiv);
        btnDot = (Button) findViewById(R.id.btnDot);
        btnEqual = (Button) findViewById(R.id.btnEqual);


        View.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final int id = v.getId();
                switch (id){
                    case R.id.btn0:
                        textView.append("0");
                        break;
                    case R.id.btn1:
                        textView.append("1");
                        break;
                    case R.id.btn2:
                        textView.append("2");
                        break;
                    case R.id.btn3:
                        textView.append("3");
                        break;
                    case R.id.btn4:
                        textView.append("4");
                        break;
                    case R.id.btn5:
                        textView.append("5");
                        break;
                    case R.id.btn6:
                        textView.append("6");
                        break;
                    case R.id.btn7:
                        textView.append("7");
                        break;
                    case R.id.btn8:
                        textView.append("8");
                        break;
                    case R.id.btn9:
                        textView.append("9");
                        break;
                    case R.id.btnAdd:
                        String screenContent = textView.getText().toString();
                        secondNumberIndex = screenContent.length()  + 1;

                        firstNumber = Double.parseDouble(screenContent);
                        textView.append("+");
                        isOpPressed = true;

                        currentOp = '+';

                        break;
                    case R.id.btnSub:
                        String screenContent3 = textView.getText().toString();
                        secondNumberIndex = screenContent3.length()  + 1;

                        firstNumber = Double.parseDouble(screenContent3);
                        textView.append("-");
                        isOpPressed = true;

                        currentOp = '-';
                        break;
                    case R.id.btnMulti:
                        String screenContent4 = textView.getText().toString();
                        secondNumberIndex = screenContent4.length()  + 1;
                        firstNumber = Double.parseDouble(screenContent4);
                        textView.append("*");
                        isOpPressed = true;
                        currentOp = '*';
                        break;
                    case R.id.btndiv:
                        String screenContent5 = textView.getText().toString();
                        secondNumberIndex = screenContent5.length()  + 1;
                        firstNumber = Double.parseDouble(screenContent5);
                        textView.append("/");
                        isOpPressed = true;
                        currentOp = '/';
                        break;
                    case R.id.btnDot:
                        textView.append(".");
                        break;
                    case R.id.btnEqual:
                        if (isOpPressed){
                            if (currentOp == '+'){
                                String screenContent2 = textView.getText().toString();
                                String secondNumberString = screenContent2.substring(secondNumberIndex, screenContent2.length());
                                double secondNumber = Double.parseDouble(secondNumberString);
                                secondNumber += firstNumber;
                                textView.setText(String.valueOf(secondNumber));
                            }
                            else if(currentOp == '-'){
                                String screenContent2 = textView.getText().toString();
                                String secondNumberString = screenContent2.substring(secondNumberIndex, screenContent2.length());
                                double secondNumber = Double.parseDouble(secondNumberString);
                                secondNumber -= firstNumber;
                                textView.setText(String.valueOf(secondNumber));
                            }
                            else if (currentOp == '*'){
                                String screenContent2 = textView.getText().toString();
                                String secondNumberString = screenContent2.substring(secondNumberIndex, screenContent2.length());
                                double secondNumber = Double.parseDouble(secondNumberString);
                                secondNumber *= firstNumber;
                                textView.setText(String.valueOf(secondNumber));
                            }
                            else if (currentOp == '/'){
                                String screenContent2 = textView.getText().toString();
                                String secondNumberString = screenContent2.substring(secondNumberIndex, screenContent2.length());
                                double secondNumber = Double.parseDouble(secondNumberString);
                                secondNumber = firstNumber / secondNumber;
                                textView.setText(String.valueOf(secondNumber));
                            }

                        }

                        break;

                }
            }
        };
        btn0.setOnClickListener(onClickListener);
        btn1.setOnClickListener(onClickListener);
        btn2.setOnClickListener(onClickListener);
        btn3.setOnClickListener(onClickListener);
        btn4.setOnClickListener(onClickListener);
        btn5.setOnClickListener(onClickListener);
        btn6.setOnClickListener(onClickListener);
        btn7.setOnClickListener(onClickListener);
        btn8.setOnClickListener(onClickListener);
        btn9.setOnClickListener(onClickListener);
        btnAdd.setOnClickListener(onClickListener);
        btnSub.setOnClickListener(onClickListener);
        btnMulti.setOnClickListener(onClickListener);
        btnDiv.setOnClickListener(onClickListener);
        btnEqual.setOnClickListener(onClickListener);
        btnDot.setOnClickListener(onClickListener);

        final Button delete = findViewById(R.id.delete);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String displayElements = textView.getText().toString();

                int length = displayElements.length();
                if (length > 0){
                    displayElements = displayElements.substring(0,length-1);
                    textView.setText(displayElements);
                }
            }
        });

        final Button clear = findViewById(R.id.clear);
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView.setText("");
            }
        });


    }
}