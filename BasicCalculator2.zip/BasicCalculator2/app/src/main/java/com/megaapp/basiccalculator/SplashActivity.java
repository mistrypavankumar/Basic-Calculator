package com.megaapp.basiccalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        //Due to this we hide the tool bar
        getSupportActionBar().hide();

        //This is used to make app work more than one work
        Thread thread = new Thread(){
            public void run(){
                //Providing delay
                try {
                    sleep(1000);   // 1000 millis = 1second
                }catch (Exception e){
                    e.printStackTrace();
                }
                finally {
                    Intent intent = new Intent(SplashActivity.this,MainActivity.class);
                    startActivity(intent);
                }
            }
        };thread.start();
    }
}